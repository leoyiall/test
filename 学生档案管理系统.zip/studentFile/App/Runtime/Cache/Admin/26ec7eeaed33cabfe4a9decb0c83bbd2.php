<?php if (!defined('THINK_PATH')) exit();?>
<link rel="stylesheet" type="text/css" href="__PUBLIC__/css/common.css"/>
<link rel="stylesheet" type="text/css" href="__PUBLIC__/css/main.css"/>
<script type="text/javascript" src="__PUBLIC__/js/libs/modernizr.min.js"></script>
<script type="text/javascript" src="__PUBLIC__/js/jquery.js"></script>
<div class="main-wrap" style="margin-left:0;">

        <div class="crumb-wrap">
            <div class="crumb-list"><i class="icon-font"></i><a href="<?php echo U('index');?>">首页</a><span class="crumb-step">&gt;</span><span class="crumb-name">学籍管理</span><script LANGUAGE="JavaScript">  if (window.print) {document.write('<form>'+ '<input type=button name=print value="打印页面" '+'onClick="javascript:window.print()"></form>');}</script></div>
        </div>
        <div class="search-wrap" style="margin-top:30px;">
            <div class="search-content">
                <form action="<?php echo U('documentList');?>" method="post">
                    <table class="search-tab">
                        <tr>
                            <th width="120">按学院查找:</th>
                            <td>
                                 <select name="cademy" id="selectCademy">
                                    <option value="0">全部</option>
                                <?php if(is_array($clist)): $i = 0; $__LIST__ = $clist;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vv): $mod = ($i % 2 );++$i;?><option value="<?php echo ($vv["id"]); ?>"><?php echo ($vv["cademy"]); ?></option><?php endforeach; endif; else: echo "" ;endif; ?>
                                </select>
                            </td>
                            <th width="120">按班级查找</th>
                            <td>
                                <select name="class" id="class">
                               <?php if(is_array($classList)): $i = 0; $__LIST__ = $classList;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vv): $mod = ($i % 2 );++$i;?><option value="<?php echo ($vv["id"]); ?>"><?php echo ($vv["cademy"]); ?></option><?php endforeach; endif; else: echo "" ;endif; ?>
                               </select> 
                            </td>
                            <td><input class="btn btn-primary btn2" name="sub" value="查询" type="submit"></td>
                        </tr>
                    </table>
                </form>
            </div>
        </div>
        <div class="result-wrap" style="margin-top:0px;">
            <form name="myform" id="myform" method="post">
                <div class="result-content">
                    <table class="result-tab" width="100%">
                        <tr>
                            <th>学号</th>
                            <th>姓名</th>
                            <th>所在学院</th>
                            <th>班级</th>
                            <th>联系电话</th>
                            <th>地址</th>
                            <th>操作</th>
                        </tr>
                    <?php if(is_array($tlist)): $i = 0; $__LIST__ = $tlist;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vv): $mod = ($i % 2 );++$i;?><tr>
                            <td><?php echo ($vv["studentNum"]); ?></td>  
                            <td><?php echo ($vv["student"]); ?></td>  
                            <td>
                            <?php echo ($vv["cademy"]); ?>
                            </td> 
                            <td><?php echo ($vv["className"]); ?></b></td> 
                            <td><?php echo ($vv["phone"]); ?></td> 
                            <td><?php echo ($vv["address"]); ?></td>
                            <td><a href="<?php echo U('document');?>?id=<?php echo ($vv["studentNum"]); ?>">查看学籍</a>
                            <a href="javascript:void(0);" data="<?php echo ($vv["studentNum"]); ?>" onclick="delStudent(this)">删除学生</a></td>
                        </tr><?php endforeach; endif; else: echo "" ;endif; ?>
                    </table>
                    <div class="list-page"> 
                        <?php echo ($page); ?>
                    </div>
                </div>
            </form>
        </div>
    </div>
 <script type="text/javascript">
     $(document).ready(function(){
         $("#selectCademy").change(function(){
               var cademy = $("#selectCademy").val();
               $.ajax({
                  url:'<?php echo U("getClass");?>',
                  type:'post',
                  data:{
                     id:cademy
                  },
                  success:function(data){
                     console.log(data);
                     var chang = data.length;
                     var html = '';
                    for(var i=0;i<chang;i++){
                        html+='<option value="'+data[i]['id']+'">'+data[i]["className"]+'</option> ';
                    }
                    $("#class").html(html);
                  },
                  error:function(e){
                     console.log(e);
                  }
               });
         });
    });
     function delStudent(obj){
        var id = $(obj).attr("data");
        if(confirm("是否删除该学生?")){
            window.location.href="<?php echo U('delDocument');?>?id="+id;
        }
     }
</script>