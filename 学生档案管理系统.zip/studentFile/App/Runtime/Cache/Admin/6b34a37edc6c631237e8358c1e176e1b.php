<?php if (!defined('THINK_PATH')) exit();?>
<link rel="stylesheet" type="text/css" href="__PUBLIC__/css/common.css"/>
<link rel="stylesheet" type="text/css" href="__PUBLIC__/css/main.css"/>
<script type="text/javascript" src="__PUBLIC__/js/libs/modernizr.min.js"></script>
<script type="text/javascript" src="__PUBLIC__/js/jquery.js"></script>
<!-- <a href="<?php echo U('index');?>">首页</a> -->
<div class="result-wrap">
<script LANGUAGE="JavaScript">  if (window.print) {document.write('<form>'+ '<input type=button name=print value="打印页面" '+'onClick="javascript:window.print()"></form>');}</script>
 <br>
    <form action="" method="post" id="myform" name="myform" enctype="multipart/form-data">
        <table class="insert-tab" width="100%">
            <tbody>
            <tr><td colspan="4">我的档案&nbsp;&nbsp; </td></tr>
            <tr>
                <th width="120"><i class="require-red">*</i>学生姓名:</th>
                <td>
                    <?php echo ($my['student']); ?>
                </td>
                <th width="120"><i class="require-red">*</i>学号:</th>
                <td>
                   <?php echo ($my['studentNum']); ?>
                </td>
            </tr>
            <tr>
               <th width="120"><i class="require-red">*</i>联系电话:</th>
               <td>
                <?php echo ($my['phone']); ?>
               </td>
               <th width="120"><i class="require-red">*</i>政治面貌:</th>
               <td>
                   <?php echo ($my['face']); ?>
               </td>
            </tr>
            <tr>
               <th width="120"><i class="require-red">*</i>教育制度:</th>
               <td>
                <?php echo ($my['teachSystem']); ?> 
               </td>
               <th width="120"><i class="require-red">*</i>毕业时间:</th>
               <td>
                  <?php echo ($my['overTime']); ?>
               </td>
            </tr>
            <tr>
                <th><i class="require-red">*</i>所属学院：</th>
                <td>
                  <?php echo ($my['cademy']); ?>
                </td>
                <th width="120"><i class="require-red">*</i>班级:</th>
                <td>
                    <?php echo ($my['className']); ?>
                </td>
            </tr>
            <tr>
               <th width="120"><i class="require-red">*</i>性别:</th>
               <td>
                <?php if($my["sex"] == 1): ?>男
                  <?php else: ?>
                    女<?php endif; ?>
               </td>
               <th width="120"><i class="require-red">*</i>住址:</th>
               <td>
                   <?php echo ($my['address']); ?> 
               </td>
            </tr>
            <tr>
                <th width="120">体重:</th>
                <td>
                   <?php echo ($my['weight']); ?>kg
                </td>
                <th width="120">身高:</th>
                <td>
                    <?php echo ($my['height']); ?>cm
                </td>
            </tr>
            <tr>
                <th>自我介绍:</th>
                <td colspan="3">
                   <?php echo ($my['introduce']); ?>
                </td>
            </tr>
              <!--   <tr>
                  <th></th>
                  <td colspan="3">
                      <input class="btn btn-primary btn6 mr10" value="发布" type="submit">
                      <input class="btn btn6" onclick="history.go(-1)" value="返回" type="button">
                  </td>
              </tr> -->
            </tbody></table>
    </form>
    <table style="margin-top:10px;" class="insert-tab" width="100%">
      <tr>
        <td colspan="6"><b><center>我的成绩</center></b></td>
      </tr>
  <tr>
      <td>学年</td>
      <td>学期</td>
      <td>课程名</td>
      <td>教课老师</td>
      <td>开课学院</td>
      <td>成绩</td>
  </tr>
 <?php if(is_array($slist)): $i = 0; $__LIST__ = $slist;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?><tr>
      <td><?php echo ($v["itemStart"]); ?>-<?php echo ($v["itemEnd"]); ?></td>
        <td><?php echo ($v["item"]); ?></td>
        <td><?php echo ($v["course"]); ?></td>
        <td><?php echo ($v["teacher"]); ?></td>
        <td><?php echo ($v["cademy"]); ?></td>
        <td><?php echo ($v["score"]); ?></td>
      </tr><?php endforeach; endif; else: echo "" ;endif; ?>
  
    </table>
</div>
</div>
<script type="text/javascript">
  /*      $(document).ready(function(){
        $("#selectCademy").change(function(){
            var cademy = $("#selectCademy").val();
            $.ajax({
               url:'<?php echo U("getClass");?>',
               type:'post',
               data:{
                  id:cademy
               },
               success:function(e){
                  console.log(e);
                  var cd = e.length;
                  var htmls = '';
                 for(var i=0;i<cd;i++){
                     htmls+='<option value="'+e[i]['id']+'">'+e[i]["className"]+'</option> ';
                 }
                 $("#class").html(htmls);
               }
            });
        });
    });*/
</script>