<?php if (!defined('THINK_PATH')) exit();?><!doctype html>
<html>
<head>
    <meta charset="UTF-8">
    <title>管理员中心</title>
    <link rel="stylesheet" type="text/css" href="__PUBLIC__/css/common.css"/>
    <link rel="stylesheet" type="text/css" href="__PUBLIC__/css/main.css"/>
    <script type="text/javascript" src="__PUBLIC__/js/libs/modernizr.min.js"></script>
    <style type="text/css">
        body{
            font-family: "微软雅黑";
        }
        .topbar-logo-wrap{
            width:100%;
            height:50px;
            background-color: #fafafa;
            float:left;
            border-bottom: 1px solid #ccc;
        }
        .topbar-logo-wrap h1 a{
            color:#333;
            font-family: "微软雅黑";
            line-height: 50px;
            margin-left:10px;
        }
        .rightMessage{
            margin-top:-40px;
            float:right;
            margin-right:50px;
        }
        .rightMessage a{
            color:#333;
        }
        .rightMessage a:hover{
            text-decoration: underline;
        }
    </style>
</head>
<body>
<!-- 头部 -->
 <style type="text/css">
	.anniu{
		dipslay:block;border:1px solid #ccc;padding:5px;background:#fff;border-radius:5px;"
	}
</style>
   <div class="topbar-logo-wrap">
       <h1><a href="<?php echo U('index');?>" style="font-size:16px;">学生档案管理系统</a></h1>
    <div class="rightMessage">
        当前用户:<?php echo ($user); ?>
        <a href="" class="anniu">修改密码</a>
        <a href="__ROOT__/index.php/Login/logout" class="anniu">退出</a>
    </div>
   </div>   
<!-- 左侧菜单 -->
<div class="container clearfix">
    <div class="sidebar-wrap">
        <div class="sidebar-title">
            <h1>菜单</h1>
        </div>
        <div class="sidebar-content">
            <ul class="sidebar-list">
                <li>
                    <a href="#"><i class="icon-font">&#xe003;</i>常用操作</a>
                    <ul class="sub-menu">
                    <?php if($power == 1): ?><li><a href=""><i class="icon-font">&#xe026;</i>添加班级</a></li>
                        <li><a href="administer-公告发布.html"><i class="icon-font">&#xe005;</i>班级管理</a></li>
                        <li><a href="administer-订单查询.html"><i class="icon-font">&#xe026;</i>添加课程</a></li>
                        <li><a href="administer-订单查询.html"><i class="icon-font">&#xe006;</i>课程管理</a></li>
                        <li><a href="administer-订单查询.html"><i class="icon-font">&#xe026;</i>添加学生</a></li>
                        <li><a href="system.html"><i class="icon-font">&#xe005;</i>学生管理</a></li><?php endif; ?>
                    <?php if($power == 0): ?><li><a href="system.html"><i class="icon-font">&#xe005;</i>我的信息</a></li>
                        <li><a href="system.html"><i class="icon-font">&#xe005;</i>我的成绩</a></li>
                        <li><a href="system.html"><i class="icon-font">&#xe005;</i>我的档案</a></li><?php endif; ?>
                    <?php if($power == 2): ?><li><a href="system.html"><i class="icon-font">&#xe005;</i>我的信息</a></li>
                        <li><a href="system.html"><i class="icon-font">&#xe005;</i>课程安排</a></li>
                        <li><a href="system.html"><i class="icon-font">&#xe005;</i>录入成绩</a></li><?php endif; ?>
                    </ul>
                </li>
            <?php if($power == 1): ?><li>
                    <a href="#"><i class="icon-font">&#xe018;</i>管理模块</a>
                    <ul class="sub-menu">
                        <li><a href="<?php echo U('addItem');?>"><i class="icon-font">&#xe005;</i>学期管理</a></li>
                        <li><a href="<?php echo U('addCademy');?>"><i class="icon-font">&#xe005;</i>学院管理</a></li>
                        <li><a href="<?php echo U('addTeacher');?>"><i class="icon-font">&#xe026;</i>添加教师</a></li>
                        <li><a href="<?php echo U('teacherList');?>"><i class="icon-font">&#xe005;</i>教师管理</a></li>
                        <li><a href="system.html"><i class="icon-font">&#xe005;</i>学籍管理</a></li>
                    </ul>
                </li><?php endif; ?>
            </ul>
        </div>
    </div>
    <!--/sidebar-->
    <div class="main-wrap">
                <div class="main-wrap">

        <div class="crumb-wrap">
            <div class="crumb-list"><i class="icon-font"></i><a href="index.html">首页</a><span class="crumb-step">&gt;</span><span class="crumb-name">分类管理</span></div>
        </div>
        <div class="search-wrap">
            <div class="search-content">
                <form action="#" method="post">
                    <table class="search-tab">
                        <tr>
                            <th width="120">选择分类:</th>
                            <td>
                                <select name="search-sort" id="">
                                    <option value="class00">全部</option>
                                    <option value="class01">运动健身</option>
                                    <option value="class02">旅游</option>
                                    <option value="class03">文学艺术</option>
                                    <option value="class04">演讲</option>
                                    <option value="class05">经济</option>
                                    <option value="class06">电影</option>
                                    <option value="class07">科技</option>
                                    <option value="class08">美食</option>
                                </select>
                            </td>
                            <th width="70">关键字:</th>
                            <td><input class="common-text" placeholder="关键字" name="keywords" value="" id="" type="text"></td>
                            <td><input class="btn btn-primary btn2" name="sub" value="查询" type="submit"></td>
                        </tr>
                    </table>
                </form>
            </div>
        </div>
        <div class="result-wrap">
            <form name="myform" id="myform" method="post">
                <div class="result-title">
                    <div class="result-list">
                        <a href="insert.html"><i class="icon-font"></i>新增课程</a>
                        <a id="batchDel" href="javascript:void(0)"><i class="icon-font"></i>批量删除</a>
                        <a id="updateOrd" href="javascript:void(0)"><i class="icon-font"></i>更新排序</a>
                    </div>
                </div>
                <div class="result-content">
                    <table class="result-tab" width="100%">
                        <tr>
                            <th class="tc" width="5%"></th>
                            <th>标签ID</th>
                            <th>标签名称</th>
                            <th>课程名称</th>
                            <th>操作</th>
                        </tr>
                        <tr>
                            <td class="tc"><input name="id[]" value="" type="checkbox"></td>
                            <td>01</td>  <!--标签ID-->
                            <th>文学艺术</th> <!--标签名称-->
                            <td><a target="_blank" href="中国传统人生智慧.html">中国传统人生智慧</a> <!--课程名称-->
                            </td>
                            <td>
                                <a class="link-update" href="#">修改</a>
                                <a class="link-del" href="#">删除</a>
                            </td>
                        </tr>
                        <tr>
                            <td class="tc"><input name="id[]" value="" type="checkbox"></td>
                            <td>08</td>  <!--标签ID-->
                            <td>科技</td> <!--标签名称-->
                            <td><a target="_blank" href="科学究竟是什么.html">科学究竟是什么</a>
                            </td>
                            <td>
                                <a class="link-update" href="#">修改</a>
                                <a class="link-del" href="#">删除</a>
                            </td>
                        </tr>
                    </table>
                    <div class="list-page"> 
                    2 条 1/1 页
                    </div>
                </div>
            </form>
        </div>
    </div>
 
    </div>
    <!--/main-->
</div>
</body>
</html>