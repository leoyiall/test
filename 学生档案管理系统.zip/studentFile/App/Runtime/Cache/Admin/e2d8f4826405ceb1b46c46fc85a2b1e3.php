<?php if (!defined('THINK_PATH')) exit();?><!doctype html>
<html>
<head>
    <meta charset="UTF-8">
    <title>管理员中心</title>
    <link rel="stylesheet" type="text/css" href="__PUBLIC__/css/common.css"/>
    <link rel="stylesheet" type="text/css" href="__PUBLIC__/css/main.css"/>
    <script type="text/javascript" src="__PUBLIC__/js/libs/modernizr.min.js"></script>
    <style type="text/css">
        body{
            font-family: "微软雅黑";
        }
        .topbar-logo-wrap{
            width:100%;
            height:50px;
            background-color: #fafafa;
            float:left;
            border-bottom: 1px solid #ccc;
        }
        .topbar-logo-wrap h1 a{
            color:#333;
            font-family: "微软雅黑";
            line-height: 50px;
            margin-left:10px;
        }
        .rightMessage{
            margin-top:-40px;
            float:right;
            margin-right:50px;
        }
        .rightMessage a{
            color:#333;
        }
        .rightMessage a:hover{
            text-decoration: underline;
        }
    </style>
</head>
<body>
<!-- 头部 -->
 <style type="text/css">
	.anniu{
		dipslay:block;border:1px solid #ccc;padding:5px;background:#fff;border-radius:5px;"
	}
</style>
   <div class="topbar-logo-wrap">
       <h1><a href="<?php echo U('index');?>" style="font-size:16px;">学生档案管理系统</a></h1>
    <div class="rightMessage">
        当前用户:<?php echo ($user); ?>
        <a href="<?php echo U('modifyPass');?>?id=<?php echo ($id); ?>" class="anniu">修改密码</a>
        <a href="__ROOT__/index.php/Login/logout" class="anniu">退出</a>
    </div>
   </div>   
<!-- 左侧菜单 -->
<div class="container clearfix">
    <div class="sidebar-wrap">
        <div class="sidebar-title">
            <h1>菜单</h1>
        </div>
        <div class="sidebar-content">
            <ul class="sidebar-list">
                <li>
                    <a href="#"><i class="icon-font">&#xe003;</i>常用操作</a>
                    <ul class="sub-menu">
                    <?php if($power == 1): ?><li><a href="<?php echo U('addclass');?>"><i class="icon-font">&#xe026;</i>添加班级</a></li>
                        <li><a href="<?php echo U('classList');?>"><i class="icon-font">&#xe005;</i>班级管理</a></li>
                        <li><a href="<?php echo U('addCourse');?>"><i class="icon-font">&#xe026;</i>添加课程</a></li>
                        <li><a href="<?php echo U('courseList');?>"><i class="icon-font">&#xe006;</i>课程管理</a></li>
                        <li><a href="<?php echo U('addStudent');?>"><i class="icon-font">&#xe026;</i>添加学生</a></li>
                        <li><a href="<?php echo U('studentList');?>"><i class="icon-font">&#xe005;</i>学生管理</a></li><?php endif; ?>
                    <?php if($power == 0): ?><li><a href="<?php echo U('myMessage');?>"><i class="icon-font">&#xe005;</i>我的信息</a></li>
                        <li><a href="<?php echo U('myCourse');?>"><i class="icon-font">&#xe005;</i>我的课程</a></li>
                        <li><a href="<?php echo U('myScore');?>"><i class="icon-font">&#xe005;</i>我的成绩</a></li>
                        <li><a href="<?php echo U('myDocument');?>"><i class="icon-font">&#xe005;</i>我的档案</a></li><?php endif; ?>
                    <?php if($power == 2): ?><li><a href="<?php echo U('teacherMessage');?>"><i class="icon-font">&#xe005;</i>我的信息</a></li>
                        <li><a href="<?php echo U('teacherCourse');?>"><i class="icon-font">&#xe005;</i>课程安排</a></li>
                        <li><a href="<?php echo U('saveScore');?>"><i class="icon-font">&#xe005;</i>录入成绩</a></li>
                        <li><a href="<?php echo U('scoreList');?>"><i class="icon-font">&#xe005;</i>成绩管理</a></li><?php endif; ?>
                    </ul>
                </li>
            <?php if($power == 1): ?><li>
                    <a href="#"><i class="icon-font">&#xe018;</i>管理模块</a>
                    <ul class="sub-menu">
                        <li><a href="<?php echo U('addItem');?>"><i class="icon-font">&#xe005;</i>学期管理</a></li>
                        <li><a href="<?php echo U('addCademy');?>"><i class="icon-font">&#xe005;</i>学院管理</a></li>
                        <li><a href="<?php echo U('addTeacher');?>"><i class="icon-font">&#xe026;</i>添加教师</a></li>
                        <li><a href="<?php echo U('teacherList');?>"><i class="icon-font">&#xe005;</i>教师管理</a></li>
                        <li><a href="system.html"><i class="icon-font">&#xe005;</i>学籍管理</a></li>
                    </ul>
                </li><?php endif; ?>
            </ul>
        </div>
    </div>
    <!--/sidebar-->
    <div class="main-wrap">
            <div class="main-wrap" style="margin-left:0;">

        <div class="crumb-wrap">
            <div class="crumb-list"><i class="icon-font"></i><a href="<?php echo U('index');?>">首页</a><span class="crumb-step">&gt;</span><span class="crumb-name">我的课程</span></div>
        </div>
        
        <div class="result-wrap" style="margin-top:80px;">
            <form name="myform" id="myform" method="post">
<!--                 <div class="result-title">
    <div class="result-list">
        <a href="<?php echo U('addCourse');?>"><i class="icon-font"></i>新增课程</a>
    </div>
</div> -->
                <div class="result-content">
                    <table class="result-tab" width="100%">
                        <tr>
                            <th>课程名</th>
                            <th>班级</th>
                            <th>学期</th>
                            <th>上课老师</th>
                            <th>开课学院</th>
                            <th>开课时间</th>
                            <th>结课时间</th>
                        </tr>
                    <?php if(is_array($mycourse)): $i = 0; $__LIST__ = $mycourse;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vv): $mod = ($i % 2 );++$i;?><tr>
                            <td><?php echo ($vv["course"]); ?></td>  
                            <td><?php echo ($vv["className"]); ?></td>  
                            <td>
                            <?php echo ($vv["itemStart"]); ?>--<?php echo ($vv["itemEnd"]); ?>
                            
                            <?php if($vv["item"] == 1): ?>第一学期
                              <?php else: ?>
                                第二学期<?php endif; ?>
                            </td> 
                            <td>[<?php echo ($vv["cademy"]); ?>]--<b><?php echo ($vv["teacher"]); ?></b></td> 
                            <td><?php echo ($vv["cademy"]); ?></td> 
                            <td><?php echo ($vv["openTime"]); ?></td>
                            <td><?php echo ($vv["overTime"]); ?></td>
                        </tr><?php endforeach; endif; else: echo "" ;endif; ?>
                    </table>
                    <div class="list-page"> 
                        <?php echo ($page); ?>
                    </div>
                </div>
            </form>
        </div>
    </div>
 
    </div>
    <!--/main-->
</div>
</body>
</html>