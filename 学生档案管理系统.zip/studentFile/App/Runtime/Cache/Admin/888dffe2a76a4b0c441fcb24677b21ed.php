<?php if (!defined('THINK_PATH')) exit();?><!doctype html>
<html>
<head>
    <meta charset="UTF-8">
    <title>管理员中心</title>
    <link rel="stylesheet" type="text/css" href="__PUBLIC__/css/common.css"/>
    <link rel="stylesheet" type="text/css" href="__PUBLIC__/css/main.css"/>
    <script type="text/javascript" src="__PUBLIC__/js/libs/modernizr.min.js"></script>
    <style type="text/css">
        body{
            font-family: "微软雅黑";
        }
        .topbar-logo-wrap{
            width:100%;
            height:50px;
            background-color: #fafafa;
            float:left;
            border-bottom: 1px solid #ccc;
        }
        .topbar-logo-wrap h1 a{
            color:#333;
            font-family: "微软雅黑";
            line-height: 50px;
            margin-left:10px;
        }
        .rightMessage{
            margin-top:-40px;
            float:right;
            margin-right:50px;
        }
        .rightMessage a{
            color:#333;
        }
        .rightMessage a:hover{
            text-decoration: underline;
        }
    </style>
</head>
<body>
<!-- 头部 -->
 <style type="text/css">
	.anniu{
		dipslay:block;border:1px solid #ccc;padding:5px;background:#fff;border-radius:5px;"
	}
</style>
   <div class="topbar-logo-wrap">
       <h1><a href="<?php echo U('index');?>" style="font-size:16px;">学生档案管理系统</a></h1>
    <div class="rightMessage">
        当前用户:<?php echo ($user); ?>
        <a href="" class="anniu">修改密码</a>
        <a href="__ROOT__/index.php/Login/logout" class="anniu">退出</a>
    </div>
   </div>   
<!-- 左侧菜单 -->
<div class="container clearfix">
    <div class="sidebar-wrap">
        <div class="sidebar-title">
            <h1>菜单</h1>
        </div>
        <div class="sidebar-content">
            <ul class="sidebar-list">
                <li>
                    <a href="#"><i class="icon-font">&#xe003;</i>常用操作</a>
                    <ul class="sub-menu">
                    <?php if($power == 1): ?><li><a href=""><i class="icon-font">&#xe026;</i>添加班级</a></li>
                        <li><a href="administer-公告发布.html"><i class="icon-font">&#xe005;</i>班级管理</a></li>
                        <li><a href="administer-订单查询.html"><i class="icon-font">&#xe026;</i>添加课程</a></li>
                        <li><a href="administer-订单查询.html"><i class="icon-font">&#xe006;</i>课程管理</a></li>
                        <li><a href="administer-订单查询.html"><i class="icon-font">&#xe026;</i>添加学生</a></li>
                        <li><a href="system.html"><i class="icon-font">&#xe005;</i>学生管理</a></li><?php endif; ?>
                    <?php if($power == 0): ?><li><a href="system.html"><i class="icon-font">&#xe005;</i>我的信息</a></li>
                        <li><a href="system.html"><i class="icon-font">&#xe005;</i>我的成绩</a></li>
                        <li><a href="system.html"><i class="icon-font">&#xe005;</i>我的档案</a></li><?php endif; ?>
                    <?php if($power == 2): ?><li><a href="system.html"><i class="icon-font">&#xe005;</i>我的信息</a></li>
                        <li><a href="system.html"><i class="icon-font">&#xe005;</i>课程安排</a></li>
                        <li><a href="system.html"><i class="icon-font">&#xe005;</i>录入成绩</a></li><?php endif; ?>
                    </ul>
                </li>
            <?php if($power == 1): ?><li>
                    <a href="#"><i class="icon-font">&#xe018;</i>管理模块</a>
                    <ul class="sub-menu">
                        <li><a href="<?php echo U('addItem');?>"><i class="icon-font">&#xe005;</i>学期管理</a></li>
                        <li><a href="<?php echo U('addCademy');?>"><i class="icon-font">&#xe005;</i>学院管理</a></li>
                        <li><a href="<?php echo U('addTeacher');?>"><i class="icon-font">&#xe026;</i>添加教师</a></li>
                        <li><a href="<?php echo U('teacherList');?>"><i class="icon-font">&#xe005;</i>教师管理</a></li>
                        <li><a href="system.html"><i class="icon-font">&#xe005;</i>学籍管理</a></li>
                    </ul>
                </li><?php endif; ?>
            </ul>
        </div>
    </div>
    <!--/sidebar-->
    <div class="main-wrap">
            <html>
<head>
    <meta charset="UTF-8">
    <title>用户中心</title>
    <link rel="stylesheet" type="text/css" href="css/common.css"/>
    <link rel="stylesheet" type="text/css" href="css/main.css"/>
    <link rel="stylesheet" type="text/css" href="css/mylessons.css"/>
    <script type="text/javascript" src="js/libs/modernizr.min.js"></script>
    <style type="text/css">
     input,button{font: 12px/1.14 "Arial","Hiragino Sans GB",\5b8b\4f53,"Georgia","serif";color: #333;outline: 0;height:28px;}
     select{height:30px;}
    </style> 
</head>
<body>
<div class="topbar-wrap white">
    <!--<div class="topbar-inner clearfix">-->
    <div></div><div></div><div></div>
        <div class="topbar-logo-wrap clearfix">
            <h1 class="topbar-logo none"><a href="index.html" class="navbar-brand">用户中心</a></h1>
        </div>
    </div>
</div>
<div class="container clearfix">
    <div class="sidebar-wrap">
        <div class="sidebar-title">
            <h1>菜单</h1>
        </div>
        <div class="sidebar-content">
            <ul class="sidebar-list">
                <li>
                    <a href="#"><i class="icon-font">&#xe003;</i>常用操作</a>
                    <ul class="sub-menu">
                        <li><a href="customer-我的课程.html"><i class="icon-font">&#xe005;</i>我的课程</a></li>
                        <li><a href="customer-订单查询.html"><i class="icon-font">&#xe006;</i>订单查询</a></li>
                        <li><a href="customer-课程出售.html"><i class="icon-font">&#xe008;</i>课程出售</a></li>
                    </ul>
                </li>
            </ul>
        </div>
    </div>
    <!--/sidebar-->
    <div class="main-wrap">

        <div class="crumb-wrap">
            <div class="crumb-list"><i class="icon-font"></i><a href="index.html">首页</a><span class="crumb-step">&gt;</span><span class="crumb-name">我的课程</span></div>
        </div>
        <div class="search-wrap">
            <div class="search-content">
                <form action="#" method="post">
                    <table class="search-tab">
                        <tr>
                            <th width="120">选择分类:</th>
                            <td>
                                <select name="search-sort" id="">
                                    <option value="">全部</option>
                                    <option value="19">运动健身</option>
                                    <option value="20">旅游</option>
                                    <option value="21">文学艺术</option>
                                    <option value="22">演讲</option>
                                    <option value="23">经济</option>
                                    <option value="24">电影</option>
                                    <option value="25">科技</option>
                                    <option value="26">美食</option>
                                </select>
                            </td>
                            <th width="70">关键字:</th>
                            <td><input class="common-text" placeholder="关键字" name="keywords" value="" id="" type="text"></td>
                            <td><input class="btn btn-primary btn2" name="sub" value="查询" type="submit"></td>
                        </tr>
                    </table>
                </form>
            </div>
        </div>

            <form name="myform" id="myform" method="post">
                <div class="result-title">
                    <div class="result-list">

                    </div>
                </div>
                <div class="result-content">
                    <div class="m-main-b"> 
                        <div class="auto-1460270624541-parent" id="j-pool">
                            <div class="m-basepool f-cb auto-1460270624541">
                                <div class="j-list">
                                    <div class="m-data-lists f-cb f-pr j-data-list">

                                        <div class="first">
                                            <div class="w-main-lib" id="MBHOHHVI7">  
                                                <a class="link" href="C:/Users/Administrator/Desktop/首页/中国传统人生智慧.html"  target="_blank"> 
                                                <div class="w-his f-pr" href=""> 
                                                    <img width="160px" height="90px" src="http://vimg1.ws.126.net/image/snapshot_movie/2016/3/I/8/MBHOHHVI8.jpg" alt="中国传统人生智慧 第1集"> 
                                                </div> 
                                                <h7>中国传统人生智慧 第1集</h7> 
                                                </a> 
                                                <span class="playli">我的评价:</span><br>
                                                <form name="formmark" id="formmark" method="get">
                                                <select name="mark" size="1">
                                                    <option value="1">1星</option>
                                                    <option value="2">2星</option>
                                                    <option value="3">3星</option>
                                                    <option value="4">4星</option>
                                                    <option value="5">5星</option>
                                                </select>&nbsp;
                                                <input type="submit" id="submit-mark1" value="提交" onclick="check()">
                                                </form>
                                            </div> 
                                        </div>
                                        <div class=""> 
                                            <div class="w-main-lib" id="M9DOKVO3K">  
                                                <a class="link" href="C:/Users/Administrator/Desktop/首页/科学究竟是什么.html"  target="_blank"> 
                                                <div class="w-his f-pr" href=""> 
                                                    <img width="160px" height="90px" src="http://vimg1.ws.126.net/image/snapshot_movie/2013/11/C/2/M9DOKV5C2.jpg" alt="科学究竟是什么 第1集"> 
                                                </div> 
                                                <h7>科学究竟是什么 第1集</h7> 
                                                </a> <br>
                                                <span class="playli">我的评价:</span><br>
                                                <form name="formmark2" id="formmark2" method="get">
                                                <select name="mark2" size="1">
                                                    <option value="1">1星</option>
                                                    <option value="2">2星</option>
                                                    <option value="3">3星</option>
                                                    <option value="4">4星</option>
                                                    <option value="5">5星</option>
                                                </select>&nbsp;
                                                <input type="submit" id="submit-mark2" value="提交" onclick="check()">
                                                </form>
                                            </div> 
                                        </div>
                                        <div class=""> 
                                            <div class="w-main-lib" id="M9S8TM7V0">  
                                                <a class="link" href="C:/Users/Administrator/Desktop/首页/美体与健身.html" title="点击继续观看" target="_blank"> 
                                                <div class="w-his f-pr" href=""> 
                                                    <img width="160px" height="90px" src="http://vimg1.ws.126.net/image/snapshot_movie/2014/5/B/Q/M9S8TLABQ.jpg" alt="美体与健身 第1集"> 
                                                </div> 
                                                <h7>美体与健身 第1集</h7> 
                                                </a> <br>
                                                <span class="playli">我的评价:</span><br>
                                                <form name="formmark3" id="formmark3" method="get">
                                                <select name="mark3" size="1">
                                                    <option value="1">1星</option>
                                                    <option value="2">2星</option>
                                                    <option value="3">3星</option>
                                                    <option value="4">4星</option>
                                                    <option value="5">5星</option>
                                                </select>&nbsp;
                                                <input type="submit" id="submit-mark3" value="提交" onclick="check()">
                                                </form>
                                            </div> 
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div> 
                    </div>
                    
                </div>
            </form>
    </div>
    <!--/main-->
</div>
</body>
</html>
    </div>
    <!--/main-->
</div>
</body>
</html>