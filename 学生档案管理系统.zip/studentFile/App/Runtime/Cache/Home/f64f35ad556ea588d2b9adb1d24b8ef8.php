<?php if (!defined('THINK_PATH')) exit();?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<link rel="stylesheet" href="__PUBLIC__/css/xgxt_login.css" />
<title>用户登录-学生档案管理系统</title>
<script type="text/javascript" src="__PUBLIC__/js/jquery.js"></script>
<script type="text/javascript">
$(document).ready(function(){
	$('#sub').click(function(){
		var yzm=$('#yzm').val();
		if(yzm.length <=0 ){
			alert("验证码不能为空");
			return;
		}
		var user=$('#user').val();
		if(user.length <=0 ){
			alert("用户名不能为空");
			return;
		}
		var pass=$('#pass').val();
		if(pass.length <=0 ){
			alert("密码不能为空");
			return;
		}
		$.ajax({
			url : "<?php echo U('Login/dologin');?>",
			type:'post',
			datatype:'json',
			data:{
				'user':user,
				'pass':pass,
				'yzm':yzm,
				't':$("input[name='t1']:checked").val()
			},
			success:function(e){
				console.log(e);
				if(e.bool){
					alert(e.info);
					setTimeout(function(){
						window.location.href=e.link;
					},1000);
				}else{
					console.log(e);
					alert(e.info);
				}
			},
			error:function(e){
				console.log(e.info);
				alert(e.info);
			}
		});
	});
});
</script>
</head>
<body>

<div id="header">
	<div class="header_title">
		<span class="title_con">学生档案管理系统</span>
	</div>
</div>

<div id="content">
	<center>
		<div class="con">
		<div class="con_title">
			<span class="con_title_sp">欢迎登录学生档案管理系统</span>
			<p style="color:red;" id="notices"></p>
		</div>
<form method="post">
		<div class="con_panel" style="position:relative;">
			<div class="con_input">
				<span>用户名：</span><input type="text" placeholder="学号/工号" autofocus name="user" id="user"/>
			</div>
			<div class="con_input">
				<span>密&nbsp;&nbsp;&nbsp;&nbsp;码：</span><input type="password" placeholder="密码" name="pass" id="pass"/>
			</div>
			<div class="con_input">
				<span>验证码：</span><input type="text" placeholder="验证码" name="verify" style="width:120px;margin-right:80px;" id="yzm"/>
				<img src="<?php echo U('verify');?>" height="32" onclick="this.src=this.src+'?'+Math.random()" title="点击更新" style="line-height:30px;position:absolute;bottom:100px;right:95px;">
			</div>
			<div class="con_select">
				<input type="radio" name="t1" value="0" checked/>学生
				<input type="radio" name="t1" value="2" />教师
				<input type="radio" name="t1" value="1" />管理员
			</div>
			<input type="button" value="登    录" class="submit-btn" id="sub"/>
			<p style="color:red;" id="notice"></p>
		</div>
	</div>
</form>
	</center>
</div>

</body>
</html>