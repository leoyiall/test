<?php
class IndexAction extends Action{
/*	public function __construct(){
		if(!session("id")){
			$this->error("页面不存在");
		}
	}*/
	public function common(){
		$id = session('id');//用户id
		$power = session('power');//用户权限
		$user = session('user');//用户名
		$s = M('student');
		$sname = $s->where("studentNum='$user'")->getField("student");
		$this->assign("user",$user);//分配用户名
		$this->assign("power",$power);//分配判断权限
		$this->assign("id",$id);//分配判断权限
		$this->assign("sname",$sname);//学名
	}
	public function itemList(){
		$i = M('item');
		import('ORG.Util.Page');// 导入分页类
		$count      = $i->count();// 查询满足要求的总记录数
		$Page       = new Page($count,15);// 实例化分页类 传入总记录数和每页显示的记录数
		$show       = $Page->show();// 分页显示输出
		// 进行分页数据查询 注意limit方法的参数要使用Page类的属性
		$list = $i->order('id desc')->limit($Page->firstRow.','.$Page->listRows)->select();
		$this->assign('itemList',$list);// 赋值数据集
		$this->assign('page',$show);// 赋值分页输出
	}
	// 学院列表
	public function cademyList(){
		$i = M('academy');
		$list = $i->order('id asc')->select();
		$this->assign("clist",$list);
	}
	// 学院列表
	public function getCademyList(){
		$i = M('academy');
		import('ORG.Util.Page');// 导入分页类
		$count      = $i->count();// 查询满足要求的总记录数
		$Page       = new Page($count,15);// 实例化分页类 传入总记录数和每页显示的记录数
		$show       = $Page->show();// 分页显示输出
		// 进行分页数据查询 注意limit方法的参数要使用Page类的属性
		$list = $i->order('id asc')->limit($Page->firstRow.','.$Page->listRows)->select();
		$this->assign('itemList',$list);// 赋值数据集
		$this->assign('page',$show);// 赋值分页输出
	}
	// 系统后台的首页
	public function index(){
		// 分配公共信息
		$this->common();
		$this->display();	
	}
	// 添加学期
	public function addItem(){
		// 分配公共信息
		$this->common();
		$this->itemList();
		$this->display();
	}
	// 执行删除学期
	public function doItemDel(){
		$id = $_GET['id'];
		$i = M('item');
		$list = $i->where("id='$id'")->delete();
		if($list){
			$this->redirect("addItem");
		}else{
			$this->error('出错,不要重复操作!');
		}
	}
	// 修改学期
	public function doItemModify(){
		$this->common();
		$id = $_GET['id'];
		$i = M('item');
		$ilist = $i->where("id='$id'")->find();
		$this->assign("ilist",$ilist);
		$this->display();
	}
	// 执行修改学期
	public function doModifyItem(){
		$id = $_POST['id'];
		$data['itemStart'] = $_POST['itemStart'];
		$data['itemEnd'] = $_POST['itemEnd'];
		$data['item'] = $_POST['item'];
		$i = M('item');
		$list = $i->where("id='$id'")->save($data);
		if($list){
			$this->redirect("addItem");
		}else{
			$this->error('出错,不要重复操作!!');
		}
	}
	//执行添加学期
	public function doAddItem(){
		$data['item'] = $_POST['item'];
		$data['itemStart'] = $_POST['itemStart'];
		$data['itemEnd'] = $_POST['itemEnd'];
		$i = M('item');
		$list = $i->add($data);
		if($list){
			$this->redirect("addItem");
		}else{
			$this->error('添加学期出错!');
		}
	}	
	// 添加学院
	public function addcademy(){
		$this->common();
		$this->getCademyList();
		$this->display();
	}
	// 执行添加学院
	public function doAddAcademy(){
		$data['cademy'] = $_POST['cademy'];
		$i = M('academy');
		$list = $i->add($data);
		if($list){
			$this->redirect("addcademy");
		}else{
			$this->error('添加出错!');
		}
	}
	// 执行删除学院
	public function doCademyDel(){
		$id = $_GET['id'];
		$i = M('academy');
		$list = $i->where("id='$id'")->delete();
		if($list){
			$this->redirect("addCademy");
		}else{
			$this->error('出错,不要重复操作!!');
		}
	}
	// 修改学院
	public function docademymodify(){
		$this->common();
		$id = $_GET['id'];
		$i = M('academy');
		$ilist = $i->where("id='$id'")->find();
		$this->assign("ilist",$ilist);
		$this->display();
	}
	// 执行修改学院
	public function doModifyXy(){
		$id = $_POST['id'];
		$data['cademy'] = $_POST['cademy'];
		$i = M('academy');
		$list = $i->where("id='$id'")->save($data);
		if($list){
			$this->redirect("addCademy");
		}else{
			$this->error('出错,不要重复操作!!');
		}
	}
	// 添加教师
	public function addTeacher(){
		$this->common();//公共信息
		$this->cademyList();//学院列表
		$this->display();
	}
	// 执行添加教师
	public function doAddTeacher(){
		$data['teacher'] = $_POST['teacher'];
		$data['teacherId'] = $_POST['teacherNum'];
		$data['cademyId'] = $_POST['cademy'];
		$data['address'] = $_POST['address'];
		$data['phone'] = $_POST['phone'];
		$data['introduce'] = $_POST['introduce'];
		$data['openTime'] = date("Y-m-d");
		$teacher = M('teacher');
		$us = M('user');
		$user['pass'] = md5($_POST['pass']);//教师工号就是登录号
		$user['user'] = $data['teacherId'];//教师密码
		$user['power'] = 2;//教师密码
		$u = $us->add($user);//添加教师
		$list = $teacher->add($data);
		if($list){
			$this->redirect("teacherList");
		}else{
			$this->error("职工号已经存在！");
		}
	}
	// 教师列表
	public function getTeacherList(){
		$tea = M('teacher_list');
		import('ORG.Util.Page');// 导入分页类
		$count      = $tea->count();// 查询满足要求的总记录数
		$Page       = new Page($count,15);// 实例化分页类 传入总记录数和每页显示的记录数
		$show       = $Page->show();// 分页显示输出
		// 进行分页数据查询 注意limit方法的参数要使用Page类的属性
		$list = $tea->limit($Page->firstRow.','.$Page->listRows)->select();
		$this->assign('tlist',$list);// 赋值数据集
		$this->assign('page',$show);// 赋值分页输出
	}
	// 老师列表
	public function teacherList(){		
		$this->cademyList();
		$this->common();
		$id = $_POST['id'];
		$key= $_POST['keywords'];
		if($id || $key){
			// 如果不为0就是不查全部
			if($id !=0 or $key){
				$tea = M('teacher_list');
				import('ORG.Util.Page');// 导入分页类
				$count      = $tea->where("cademyId='$id' or teacher like '%{$key}%'")->count();// 查询满足要求的总记录数
				$Page       = new Page($count,15);// 实例化分页类 传入总记录数和每页显示的记录数
				$show       = $Page->show();// 分页显示输出
				// 进行分页数据查询 注意limit方法的参数要使用Page类的属性
				$list = $tea->where("cademyId='$id' or teacher like '%{$key}%'")->limit($Page->firstRow.','.$Page->listRows)->select();
				$this->assign('tlist',$list);// 赋值数据集
				$this->assign('page',$show);// 赋值分页输出
			}else{
				$this->getTeacherList();//查全部教师出来
			}
		}else{
			$this->getTeacherList();
		}
		$this->display();
	}
	// 删除教师
	public function delTeacher(){
		$id = $_GET['id'];
		$t = M('teacher');
		$list = $t->where("id='$id'")->delete();
		if($list){
			$this->redirect("teacherList");
		}else{
			$this->error("出错,不要重复操作!!");
		}
	}
	// 修改教师
	public function modifyTeacher(){
		$id = $_GET['id'];
		$i = M('teacher_list');
		$ilist = $i->where("id='$id'")->find();
		$this->assign("ilist",$ilist);
		$this->common();
		$this->cademyList();//学院列表
		$this->display();
	}
	// 执行修改教师
	public function doModifyTeacher(){
		$id = $_POST['id'];
		$data['teacher'] = $_POST['teacher'];//教师名称
		$data['cademyId'] = $_POST['cademy'];//学院
		$data['address'] = $_POST['address'];//地址
		$data['phone'] = $_POST['phone'];//电话
		$data['introduce'] = $_POST['introduce'];//介绍
		$i = M('teacher');
		$list = $i->where("id='$id'")->save($data);
		if($list){
			$this->redirect("teacherList");
		}else{
			$this->error('出错,不要重复操作!!');
		}
	}
	// 添加班级
	public function addClass(){
		$this->common();
		$this->cademyList();
		$this->display();
	}
	// 添加班级
	public function doAddClass(){
		$data['className'] = $_POST['className'];//班级名称
		$data['classNum'] = $_POST['classNum'];//班级名称
		$data['academyId'] = $_POST['cademy'];//班级名称
		$data['classTime'] = date("Y");//开班时间
		$c = M('class');
		$clist = $c->add($data);
		if($clist){
			$this->redirect("classList");
		}else{
			$this->error("编号重复了!");
		}
	}
	// 获取班级列表
	public function getClassList(){
		$tea = M('class_list');
		import('ORG.Util.Page');// 导入分页类
		$count      = $tea->count();// 查询满足要求的总记录数
		$Page       = new Page($count,15);// 实例化分页类 传入总记录数和每页显示的记录数
		$show       = $Page->show();// 分页显示输出
		// 进行分页数据查询 注意limit方法的参数要使用Page类的属性
		$list = $tea->limit($Page->firstRow.','.$Page->listRows)->select();
		$this->assign('tlist',$list);// 赋值数据集
		$this->assign('page',$show);// 赋值分页输出
	}
	// 获取部分班级列表
	public function getClassMethod($id){
		$c = M('class_list');
		$classList = $c->where("id='$id'")->select();
		$this->assign("classList",$classList);
	}
	// 课堂列表
	public function classList(){
		$this->common();
		$this->cademyList();
		$id = $_POST['id'];
		$key= $_POST['keywords']?$_POST['keywords']:'0';
		if($id || $key){
			// 如果不为0就是不查全部
			if($id !=0 or $key){
				$tea = M('class_list');
				import('ORG.Util.Page');// 导入分页类
				$count      = $tea->where("academyId='$id' or className like '%{$key}%'")->count();// 查询满足要求的总记录数
				$Page       = new Page($count,15);// 实例化分页类 传入总记录数和每页显示的记录数
				$show       = $Page->show();// 分页显示输出
				// 进行分页数据查询 注意limit方法的参数要使用Page类的属性
				if($key != '0'){
					$list = $tea->where("academyId='$id' or className like '%{$key}%'")->limit($Page->firstRow.','.$Page->listRows)->select();
				}else{
					$list = $tea->where("academyId='$id' ")->limit($Page->firstRow.','.$Page->listRows)->select();
				}
				$this->assign('tlist',$list);// 赋值数据集
				$this->assign('page',$show);// 赋值分页输出
			}else{
				$this->getClassList();//查全部班级出来
			}
		}else{
			$this->getClassList();
		}
		$this->display();
	}
	// 删除课堂
	public function delClass(){
		$id = $_GET['id'];
		$i = M('class');
		$list = $i->where("id='$id'")->delete();
		if($list){
			$this->redirect("classList");
		}else{
			$this->error('出错,不要重复操作!!');
		}
	}
	// 修改班级
	public function modifyClass(){
		$this->cademyList();//学院列表
		$this->common();
		$id = $_GET['id'];
		$i = M('class_list');
		$ilist = $i->where("id='$id'")->find();
		$this->assign("ilist",$ilist);
		$this->display();
	}
	// 执行修改班级
	public function doModifyClass(){
		$id = $_POST['id'];
		$data['className'] = $_POST['className'];
		$data['classNum'] = $_POST['classNum'];
		$data['academyId'] = $_POST['cademy'];
		$i = M('class');
		$list = $i->where("id='$id'")->save($data);
		if($list){
			$this->redirect("classList");
		}else{
			$this->error('出错,不要重复操作!!');
		}
	}
	// 添加课程
	public function addCourse(){
		// 分配公共信息
		$this->common();//公共信息
		$this->itemList();//学期列表
		$this->cademyList();//学院列表
		$this->getTeacherList();//教师列表
		//$this->getClassMethod();//班级列表列表
		$this->display();
	}
	// 获取对应的班级
	public function getClass(){
		$id = $_POST['id'];
		$t = M('class');
		$list = $t->where("academyId='$id'")->select();
		$this->ajaxReturn($list);
	}
	// 获取对应的所属学院的教师
	public function getTeacher(){
		$id = $_POST['id'];
		$t = M('teacher');
		$list = $t->where("cademyId='$id'")->select();
		$this->ajaxReturn($list);
	}
	// 添加课程
	public function doAddCourse(){
		$data['course'] = $_POST['course'];
		$data['cademyId'] = $_POST['cademy'];
		$data['teacherId'] = $_POST['teacher'];
		$data['classId'] = $_POST['class'];
		$data['itemId'] = $_POST['item'];
		$data['openTime'] = $_POST['startTime'];
		$data['overTime'] = $_POST['endTime'];
		$a = M('course');
		$alist = $a->add($data);
		if($alist){
			$this->redirect('courselist');
		}else{
			$this->error("出错，请不要重复操作!");
		}
	}
	// 获取课程列表
	public function getCourseList(){
		$i = M('course_list');
		import('ORG.Util.Page');// 导入分页类
		$count      = $i->count();// 查询满足要求的总记录数
		$Page       = new Page($count,15);// 实例化分页类 传入总记录数和每页显示的记录数
		$show       = $Page->show();// 分页显示输出
		// 进行分页数据查询 注意limit方法的参数要使用Page类的属性
		$list = $i->order('id desc')->limit($Page->firstRow.','.$Page->listRows)->select();
		$this->assign('tlist',$list);// 赋值数据集
		$this->assign('page',$show);// 赋值分页输出
	}
	// 
	// 教师列表
	public function courselist(){
		$this->common();
		$this->cademyList();
		$this->itemList();//学期列表
		$this->getCourseList();//获取课程列表
		$cademy = $_POST['cademy'];
		$item = $_POST['item'];
		$key= $_POST['keywords']?$_POST['keywords']:0;
		if($cademy || $item || $key){
			// 如果不为0就是不查全部
			if($cademy  || $item || $key){
				$tea = M('course_list');
				import('ORG.Util.Page');// 导入分页类
				$count      = $tea->where("cademyId='$cademy' or itemId like '%{$item}%' or course like '%{$key}%'")->count();// 查询满足要求的总记录数
				$Page       = new Page($count,15);// 实例化分页类 传入总记录数和每页显示的记录数
				$show       = $Page->show();// 分页显示输出
				// 进行分页数据查询 注意limit方法的参数要使用Page类的属性
				$list = $tea->where("cademyId='$cademy' or itemId like '%{$item}%' or course like '%{$key}%'")->limit($Page->firstRow.','.$Page->listRows)->select();
				$this->assign('tlist',$list);// 赋值数据集
				$this->assign('page',$show);// 赋值分页输出
			}else{
				$this->getCourseList();//查全部课程出来
			}
		}else{
			$this->getCourseList();
		}
		$this->display();
	}
	// 删除前一个
	public function delCourse(){
		$id = $_GET['id'];
		$i = M('course');
		$list = $i->where("id='$id'")->delete();
		if($list){
			$this->redirect("courseList");
		}else{
			$this->error('出错,不要重复操作!');
		}
	}
	// 修改课程
	public function modifyCourse(){
		$this->common();
		$this->cademyList();
		$this->itemList();//学期列表
		$this->getCourseList();//获取课程列表
		$id = $_GET['id'];
		$i = M('course_list');
		$ilist = $i->where("id='$id'")->find();
		$this->assign("course",$ilist);
		$this->display();
	}
	// 执行修改课程
	public function doModifyCourse(){
		$id = $_POST['id'];
		$data['course'] = $_POST['course'];
		$data['cademyId'] = $_POST['cademy'];
		$data['teacherId'] = $_POST['teacher'];
		$data['classId'] = $_POST['class'];
		$data['itemId'] = $_POST['item'];
		$data['openTime'] = $_POST['startTime'];
		$data['overTime'] = $_POST['endTime'];
		$i = M('course');
		$list = $i->where("id='$id'")->save($data);
		if($list){
			$this->redirect("courseList");
		}else{
			$this->error('出错,不要重复操作!!');
		}	
	}
	// 添加学生
	public function addStudent(){
		$this->common();
		$this->cademyList();
		$this->display();
	}
	// 执行添加学生
	public function doAddStudent(){
		$data['student'] = $_POST['student'];//学生姓名
		$data['studentNum'] = $_POST['studentNum'];//学号
		$data['phone'] = $_POST['phone'];//电话
		$data['sex'] = $_POST['sex'];//性别
		$data['face'] = $_POST['zhengzhi'];//政治面貌
		$data['teachSystem'] = $_POST['teach'];//教育制度3年还是4年
		$data['overTime'] = $_POST['biye'];//毕业时间
		$data['cademyId'] = $_POST['cademy'];//学院
		$data['classId'] = $_POST['class'];//班级
		$data['address'] = $_POST['address'];//地址
		$data['weight'] = $_POST['weight'];//体重
		$data['height'] = $_POST['height'];//高度
		$data['introduce'] = $_POST['introduce'];//自我介绍
		$data['openTime'] = date("Y-m");//注册年限
		// 同时把这个学生注册到登录表里面
		$user['user'] = $_POST['studentNum'];//学号
		$user['pass'] = md5("123456");//默认密码
		$i = M('student');
		$u = M('user');
		$list = $i->add($data);
		$ulist = $u->add($user);
		if($list){
			$this->redirect("StudentList");
		}else{
			$this->error('学号已存在,出错!');
		}
	}
	// 获取学生列表
	public function getStudentList(){
		$i = M('student_list');
		import('ORG.Util.Page');// 导入分页类
		$count      = $i->count();// 查询满足要求的总记录数
		$Page       = new Page($count,15);// 实例化分页类 传入总记录数和每页显示的记录数
		$show       = $Page->show();// 分页显示输出
		// 进行分页数据查询 注意limit方法的参数要使用Page类的属性
		$list = $i->order('id desc')->limit($Page->firstRow.','.$Page->listRows)->select();
		$this->assign('tlist',$list);// 赋值数据集
		$this->assign('page',$show);// 赋值分页输出
	}
	// 获取查询的学生列表
	public function classLie(){
		$c = M('class_list');
		$l = $c->select();
		$this->assign("l",$l);
	}
	// 学生列表
	public function studentList(){
		$this->common();
		$this->cademyList();//学院列表
		$this->classLie();//获取班级列表
		$cademy = $_POST['cademy'];
		$class = $_POST['class'];
		$key= $_POST['keywords']?$_POST['keywords']:'x';
		if($cademy || $class || $key !='x'){
			// 如果不为0就是不查全部
			if($cademy  || $item || $key){
				$tea = M('student_list');
				import('ORG.Util.Page');// 导入分页类
				$count      = $tea->where("cademyId='$cademy' or class like '%{$class}%' or student like '%{$key}%'")->count();// 查询满足要求的总记录数
				$Page       = new Page($count,15);// 实例化分页类 传入总记录数和每页显示的记录数
				$show       = $Page->show();// 分页显示输出
				// 进行分页数据查询 注意limit方法的参数要使用Page类的属性
				// if($key == 'x'){
					$list = $tea->where("cademyId='$cademy' or classId='$class' or student like '%{$key}%'")->limit($Page->firstRow.','.$Page->listRows)->select();
				// }else{
					// $list = $tea->where("cademyId='$cademy' or classId='$class'")->limit($Page->firstRow.','.$Page->listRows)->select();
				// }
				$this->assign('tlist',$list);// 赋值数据集
				$this->assign('page',$show);// 赋值分页输出
			}else{
				$this->getStudentList();//获取学生列表
			}
		}else{
			$this->getStudentList();//获取学生列表
		}
		$this->display();
	}
	// 删除学生
	public function delStudent(){
		$id = $_GET['id'];
		$i = M('student');
		$list = $i->where("id='$id'")->delete();
		if($list){
			$this->redirect("studentList");
		}else{
			$this->error('出错,不要重复操作!');
		}
	}
	// 修改学生
	public function modifyStudent(){
		$this->common();
		$this->cademyList();//学院
		$id = $_GET['id'];
		$i = M('student_list');
		$ilist = $i->where("id='$id'")->find();
		$this->assign("ilist",$ilist);
		$this->display();
	}
	// 执行修改学生
	public function domodifyStudent(){
		$id = $_POST['id'];
		$data['student'] = $_POST['student'];//学生姓名
		$data['phone'] = $_POST['phone'];//电话
		$data['sex'] = $_POST['sex'];//性别
		$data['face'] = $_POST['zhengzhi'];//政治面貌
		$data['teachSystem'] = $_POST['teach'];//教育制度3年还是4年
		$data['overTime'] = $_POST['biye'];//毕业时间
		$data['cademyId'] = $_POST['cademy'];//学院
		$data['classId'] = $_POST['class'];//班级
		$data['address'] = $_POST['address'];//地址
		$data['weight'] = $_POST['weight'];//体重
		$data['height'] = $_POST['height'];//高度
		$data['introduce'] = $_POST['introduce'];//自我介绍
		$s = M('student');
		$list = $s->where("id='$id'")->save($data);
		if($list){
			$this->redirect("studentList");
		}else{
			$this->error('出错,不要重复操作!');
		}
	}
	// 学生页面的————我的信息
	public function myMessage(){
		$this->common();
		$s = M('student_list');
		$id = session('user');
		$my = $s->where("studentNum='$id'")->find();
		$this->assign("my",$my);
		$this->display();
	}
	// 学生页面的————我的课程
	public function myCourse(){
		$this->common();
		$s = M('student');
		$course = M('course_list');
		$id = session('user');
		$classId = $s->where("studentNum='$id'")->getField("classId");
		import('ORG.Util.Page');// 导入分页类
		$count      = $course->where("classId = $classId")->count();// 查询满足要求的总记录数
		$Page       = new Page($count,15);// 实例化分页类 传入总记录数和每页显示的记录数
		$show       = $Page->show();// 分页显示输出
		$my = $course->where("classId = $classId")->select();
		$this->assign('page',$show);//分配分页
		$this->assign("tlist",$my);
		$this->display();
	}
	// 学生页面的————我的课程
	public function myScore(){
		$this->common();
		$this->itemList();
		$id = session("user");
		$course = M('score_list');
		$id = session('user');
		import('ORG.Util.Page');// 导入分页类
		$count      = $course->where("studentNum = '$id'")->count();// 查询满足要求的总记录数
		$Page       = new Page($count,15);// 实例化分页类 传入总记录数和每页显示的记录数
		$show       = $Page->show();// 分页显示输出
		$itemId = $_POST['item'];
		if($itemId){
			$my = $course->where("studentNum = '$id' and itemId='$itemId'")->select();
		}else{
			$my = $course->where("studentNum = '$id'")->select();	
		}
		$this->assign('page',$show);//分配分页
		$this->assign("tlist",$my);
		$this->display();
	}
	// 教师信息
	public function teacherMessage(){
		$this->common();
		$s = M('teacher_list');
		$id = session('user');
		$my = $s->where("teacherId='$id'")->find();
		$this->assign("my",$my);
		$this->display();	
	}
	// 教师课程安排
	public function teacherCourse(){
		$this->common();
		$s = M('teacher_course');
		$id = session('user');
		$my = $s->where("teacherId='$id'")->select();
		$this->assign("mycourse",$my);
		$this->display();	
	}
	// 老师录入成绩
	public function saveScore(){
		$this->common();
		$this->itemList();
		$this->cademyList();
		$s = M('stu_course');
		$id = session('user');
		$cademy = $_POST['cademy'];
		$item = $_POST['item'];
		import('ORG.Util.Page');// 导入分页类
		$count      = $s->where("teacherId = '$id'")->count();// 查询满足要求的总记录数
		$Page       = new Page($count,15);// 实例化分页类 传入总记录数和每页显示的记录数
		$show       = $Page->show();// 分页显示输出
		if($cademy || $item){
			$lists = $s->where("teacherId = '$id' and (cademyId = '$cademy' or itemId = '$item')")->limit($Page->firstRow.','.$Page->listRows)->select();
		}else{
			$lists = $s->where("teacherId = '$id'")->limit($Page->firstRow.','.$Page->listRows)->select();	
		}
		$this->assign("mycourse",$lists);
		$this->display();
	}
	// 成绩管理/
	public function scoreList(){
		$this->common();
		$this->getClassList();
		$s = M('score_list');
		$class = $_POST['class'];
		if($class){
			$sc = $s->where("classId='$class'")->select();
		}else{
			$sc = $s->select();
		}
		$this->assign("sc",$sc);
		$this->display();
	}
	// ajax存成绩
	public function ajaxScore(){
		$data['course'] = $_POST['courseName'];//课程名
		$data['classId'] = $_POST['classId'];//班级id
		$data['teacherId'] = $_POST['teacherId'];//老师编号
		$data['score'] = $_POST['score'];//成绩
		$data['studentId'] = $_POST['studentNum'];//学生编号
		$data['itemId'] = $_POST['itemId'];//学期id
		$data['stuId'] = $_POST['stuId'];//学生列表id
		$score = M('score');
		$list = $score->add($data);
		if($list){
			$bool = 1;	
		}else{
			$bool = 0;
		}
		$this->ajaxReturn($bool);
	}
	// 查找学生成绩
	public function doModifyScore(){
		$id = $_GET['id'];
		$sc = M('scoreList');
		$list = $sc->where("scid='$id'")->find();
		$this->assign("list",$list);
		$this->display();
	}
	// 修改成绩
	public function modifyScore(){
		$id = $_POST['id'];
		$s = M('score');
		$data['score'] = $_POST['score'];
		$list = $s->where("id='$id'")->save($data);
		if($list){
			$this->redirect("scoreList");
		}else{
			$this->error("系统出现问题已不能改成绩了!");
		}
	}
	// 修改密码
	public function modifyPass(){
		$this->common();
		$id = $_GET['id'];
		$this->assign("id",$id);
		$this->display();
	}

	// 执行修改密码
	public function doModifyPass(){
		$id = $_POST['id'];
		$user = M('user');
		$l = $user->where("id='$id'")->find();
		if($l['pass'] != md5($_POST['oldPass'])){
			$this->error("旧密码不正确!");
		}
		if($_POST['newPass'] != $_POST['reNewPass']){
			$this->error("两次密码不一致!");
		}
		$data['pass'] = md5($_POST['newPass']);
		$list = $user->where("id='$id'")->save($data);
		if($list){
			$this->success("修改密码成功!");
		}else{
			$this->error("修改密码失败!");
		}
		$this->display();
	}
	// 我的档案
	public function myDocument(){
		$this->common();
		$s = M('student_list');
		$d = M('score_list');
		$id = session('user');
		$my = $s->where("studentNum='$id'")->find();
		$sList = $d->where("studentNum='$id'")->order("itemStart asc")->select();
		$this->assign("my",$my);
		$this->assign("slist",$sList);
		$this->display();
	}
	// 档案列表
	public function documentList(){
		$this->common();
		$this->cademyList();
		$tea = M('student_list');
		import('ORG.Util.Page');// 导入分页类
		$count      = $tea->count();// 查询满足要求的总记录数
		$Page       = new Page($count,15);// 实例化分页类 传入总记录数和每页显示的记录数
		$show       = $Page->show();// 分页显示输出
		// 进行分页数据查询 注意limit方法的参数要使用Page类的属性
		$class = $_POST['class'];//获取班级id
		if($class){
			$list = $tea->where("classId='$class'")->limit($Page->firstRow.','.$Page->listRows)->select();
		}else{
			$list = $tea->limit($Page->firstRow.','.$Page->listRows)->select();
		}
		$this->assign('tlist',$list);// 赋值数据集
		$this->assign('page',$show);// 赋值分页输出
		$this->display();
	}
	// 学生档案列表
	public function document(){
		$s = M('student_list');
		$d = M('score_list');
		$id = $_GET['id'];
		$my = $s->where("studentNum='$id'")->find();
		$sList = $d->where("studentNum='$id'")->order("itemStart asc")->select();
		$this->assign("my",$my);
		$this->assign("slist",$sList);
		$this->display();
	}
	// 获取对应的学院里的班级
	public function delDocument(){
		$id = $_GET['id'];
		$s = M('student');//删除学生
		$sc = M('score');//成绩
		$ds = $s->where("studentNum='$id'")->delete();
		$mesc = $sc->where("studentId='$id'")->select();
		for($i=0;$i<count($mesc);$i++){
			$dsc = $s->where("studentId='$id'")->delete();
		}
		if($mes and $dsc){
			$this->redire("documentList");
		}else{
			$this->error('系统故障!');
		}
	}
}