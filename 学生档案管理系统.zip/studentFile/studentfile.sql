/*
Navicat MySQL Data Transfer

Source Server         : 127.0.0.1_3306
Source Server Version : 50617
Source Host           : 127.0.0.1:3306
Source Database       : studentfile

Target Server Type    : MYSQL
Target Server Version : 50617
File Encoding         : 65001

Date: 2016-09-27 20:17:59
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for academy
-- ----------------------------
DROP TABLE IF EXISTS `academy`;
CREATE TABLE `academy` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cademy` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of academy
-- ----------------------------
INSERT INTO `academy` VALUES ('1', '计算机信息与工程学院');
INSERT INTO `academy` VALUES ('2', '体育学院');
INSERT INTO `academy` VALUES ('3', '艺术学院');
INSERT INTO `academy` VALUES ('4', '师范学院');
INSERT INTO `academy` VALUES ('5', '文传学院');
INSERT INTO `academy` VALUES ('6', '物电学院');
INSERT INTO `academy` VALUES ('7', '化生学院');
INSERT INTO `academy` VALUES ('8', '外语学院');
INSERT INTO `academy` VALUES ('9', '数统学院');
INSERT INTO `academy` VALUES ('10', '经管学院');

-- ----------------------------
-- Table structure for class
-- ----------------------------
DROP TABLE IF EXISTS `class`;
CREATE TABLE `class` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `studentSum` int(11) DEFAULT NULL,
  `className` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `classNum` int(11) DEFAULT NULL,
  `academyId` int(11) DEFAULT NULL,
  `classTime` int(11) DEFAULT NULL,
  `xueyuan` int(11) DEFAULT NULL COMMENT '学院',
  PRIMARY KEY (`id`),
  UNIQUE KEY `classnum` (`classNum`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of class
-- ----------------------------

-- ----------------------------
-- Table structure for course
-- ----------------------------
DROP TABLE IF EXISTS `course`;
CREATE TABLE `course` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `itemId` int(11) DEFAULT NULL,
  `teacherId` int(11) DEFAULT NULL,
  `classId` int(11) DEFAULT NULL,
  `studentSum` int(11) DEFAULT NULL,
  `course` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `openTime` varchar(11) DEFAULT NULL,
  `overTime` varchar(11) DEFAULT NULL,
  `studentId` int(11) DEFAULT NULL,
  `cademyId` int(11) DEFAULT NULL COMMENT '学院id',
  `score` float DEFAULT NULL COMMENT '成绩',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of course
-- ----------------------------

-- ----------------------------
-- Table structure for item
-- ----------------------------
DROP TABLE IF EXISTS `item`;
CREATE TABLE `item` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `item` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `itemStart` int(11) DEFAULT NULL,
  `itemEnd` int(11) DEFAULT NULL COMMENT '年份',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of item
-- ----------------------------

-- ----------------------------
-- Table structure for score
-- ----------------------------
DROP TABLE IF EXISTS `score`;
CREATE TABLE `score` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `course` varchar(255) CHARACTER SET utf8 DEFAULT NULL COMMENT '课程名',
  `teacherId` int(11) DEFAULT NULL,
  `score` decimal(10,0) DEFAULT NULL,
  `classId` int(11) DEFAULT NULL,
  `studentId` int(11) DEFAULT NULL,
  `itemId` int(11) DEFAULT NULL,
  `stuId` int(11) DEFAULT NULL COMMENT '学生视图的id',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of score
-- ----------------------------

-- ----------------------------
-- Table structure for student
-- ----------------------------
DROP TABLE IF EXISTS `student`;
CREATE TABLE `student` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `student` varchar(255) CHARACTER SET utf8 DEFAULT NULL COMMENT '学生姓名',
  `sex` int(11) DEFAULT '0' COMMENT '性别',
  `classId` int(11) DEFAULT NULL COMMENT '班级id',
  `studentNum` int(11) DEFAULT NULL COMMENT '学号',
  `height` varchar(10) DEFAULT NULL COMMENT '身高',
  `weight` varchar(10) DEFAULT NULL COMMENT '体重',
  `teachSystem` varchar(255) CHARACTER SET utf8 DEFAULT NULL COMMENT '教育制度',
  `address` varchar(255) CHARACTER SET utf8 NOT NULL COMMENT '住址',
  `face` varchar(255) CHARACTER SET utf8 DEFAULT NULL COMMENT '政治面貌',
  `introduce` varchar(255) CHARACTER SET utf8 DEFAULT NULL COMMENT '自我介绍',
  `openTime` varchar(11) DEFAULT NULL COMMENT '入学时间',
  `overTime` varchar(11) DEFAULT NULL COMMENT '毕业时间',
  `userId` int(11) DEFAULT NULL COMMENT '学生id',
  `cademyId` int(11) DEFAULT NULL COMMENT '所属学院',
  `phone` int(11) DEFAULT NULL COMMENT '联系电话',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of student
-- ----------------------------

-- ----------------------------
-- Table structure for teacher
-- ----------------------------
DROP TABLE IF EXISTS `teacher`;
CREATE TABLE `teacher` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `teacher` varchar(255) CHARACTER SET utf8 DEFAULT NULL COMMENT '教师名称',
  `phone` varchar(11) DEFAULT NULL COMMENT '电话',
  `introduce` varchar(255) CHARACTER SET utf8 DEFAULT NULL COMMENT '自我介绍',
  `cademyId` int(11) DEFAULT NULL COMMENT '学院id',
  `address` varchar(255) CHARACTER SET utf8 DEFAULT NULL COMMENT '住址',
  `openTime` varchar(11) DEFAULT NULL COMMENT '入职时间',
  `teacherId` int(11) DEFAULT NULL COMMENT '教师用户id',
  `isScore` int(11) DEFAULT '0' COMMENT '判断是否有成绩',
  PRIMARY KEY (`id`),
  UNIQUE KEY `user` (`teacherId`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of teacher
-- ----------------------------

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user` varchar(25) DEFAULT NULL,
  `pass` varchar(100) DEFAULT NULL,
  `power` int(11) DEFAULT '0' COMMENT '登录权限',
  `isOne` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `user` (`user`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES ('1', 'admin', '21232f297a57a5a743894a0e4a801fc3', '1', '0');

-- ----------------------------
-- View structure for class_list
-- ----------------------------
DROP VIEW IF EXISTS `class_list`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost`  VIEW `class_list` AS select c.*,a.cademy from class c,academy a where c.academyId = a.id ;

-- ----------------------------
-- View structure for course_list
-- ----------------------------
DROP VIEW IF EXISTS `course_list`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER  VIEW `course_list` AS SELECT
	c.*, i.item,i.itemStart,i.itemEnd, cl.className, t.teacher,a.cademy
FROM
	class cl,
	course c,
	item i,
	teacher t,
	academy a
WHERE
	t.id = c.teacherId
AND c.classId = cl.id
AND c.itemId = i.id
AND c.cademyId = a.id ;

-- ----------------------------
-- View structure for score_list
-- ----------------------------
DROP VIEW IF EXISTS `score_list`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER  VIEW `score_list` AS select s.*,c.score,c.id scid from stu_course s,score c where s.teacherId = s.teacherId and s.studentNum = c.studentId and c.stuId = s.id and c.course = s.course ;

-- ----------------------------
-- View structure for student_list
-- ----------------------------
DROP VIEW IF EXISTS `student_list`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost`  VIEW `student_list` AS select s.*,c.className,a.cademy from student s,class c,academy a where s.classId = c.id and s.cademyId = a.id ;

-- ----------------------------
-- View structure for stu_course
-- ----------------------------
DROP VIEW IF EXISTS `stu_course`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER  VIEW `stu_course` AS SELECT
	s.*, c.course,
	t.teacher,
	t.teacherId,
	i.item,
	i.itemStart,
	i.itemEnd,
	c.itemId
FROM
	student_list s,
	course c,
	teacher t,
	item i
WHERE
	s.classId = c.classId
AND c.teacherId = t.id
AND c.itemId = i.id ;

-- ----------------------------
-- View structure for teacher_course
-- ----------------------------
DROP VIEW IF EXISTS `teacher_course`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost`  VIEW `teacher_course` AS SELECT
	c.course,
	c.openTime,
	c.overTime,
	t.teacher,
	t.teacherId,
	i.item,
	i.itemStart,
	i.itemEnd,
	cl.className,
	a.cademy
FROM
	course c,
	teacher t,
	class cl,
  item i,
	academy a
WHERE
	c.teacherId = t.id
AND cl.id = c.classId
AND i.id = c.itemId
AND a.id = c.cademyId ;

-- ----------------------------
-- View structure for teacher_list
-- ----------------------------
DROP VIEW IF EXISTS `teacher_list`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost`  VIEW `teacher_list` AS select t.*,c.cademy from teacher t,academy c where t.cademyId = c.id ;
